# راه‌اندازی CryptoSniper — نسخه تجمعی استیج ۱۴

نیازها: Python 3.12 یا نسخه سازگار قفل وابستگی‌ها، PostgreSQL 16، Redis 7، uv و پردازش‌های مستقل Web، Worker و Beat. Node.js برای اجرا لازم نیست. وابستگی‌های دقیق در `uv.lock` ثبت شده‌اند. Django 5.2 LTS انتخاب شده است؛ نسخه patch نصب‌شده 5.2.18 است.

## محیط توسعه

از ریشه مخزن:

```bash
uv sync --frozen
uv run python scripts/bootstrap.py
docker compose up -d postgres redis
uv run python backend/manage.py migrate
uv run python backend/manage.py collectstatic --noinput
uv run python backend/manage.py createsuperuser
uv run python backend/manage.py runserver 127.0.0.1:8000
```

Docker فقط گزینه راحت توسعه است. روی هاست یا سیستم دارای PostgreSQL و Redis، مقادیر URL در `.env` را با سرویس‌های واقعی هماهنگ کنید و دستور compose را حذف کنید. اسکریپت bootstrap راز تصادفی و رمز PostgreSQL تولید می‌کند، آنها را چاپ نمی‌کند و فایل موجود را بازنویسی نمی‌کند. هیچ حساب با رمز پیش‌فرض داخل پروژه وجود ندارد. PostgreSQL توسعه برای اجرای pytest باید اجازه ساخت test database داشته باشد.

در ترمینال‌های جدا، پردازش‌ها را اجرا کنید:

```bash
for queue in orders reports signals market_data trailing alerts maintenance; do
  uv run --env-file .env celery --workdir backend -A config worker -Q "$queue" --concurrency=1 -n "$queue@%h" &
done
uv run --env-file .env celery --workdir backend -A config beat --schedule .runtime/celerybeat-schedule
```

قبل اجرای Beat پوشه `.runtime` را ایجاد کنید. فقط یک instance از Beat اجرا شود. Worker سفارش و Worker گزارش جدا هستند؛ وظیفه سنگین گزارش نباید پردازش سفارش را متوقف کند. صف سفارش ورود و بستن Paper را مستقل از مرورگر اجرا می‌کند؛ صف trailing خروج‌های Paper و صف maintenance بازیابی و scanner را انجام می‌دهند. اجرای واقعی سفارش غیرفعال است.

صفحه ورود: `http://127.0.0.1:8000/auth/login/`؛ پس از ورود صفحه نمای کلی و `/system/` برای بررسی سرویس‌ها در دسترس است. پروفایل، نشست‌های فعال، بازیابی رمز، پیش‌فرض‌های معامله و گزارش امنیتی از منوی تنظیمات در دسترس‌اند.

مرکز صرافی در `/exchanges/` قرار دارد. برای مشاهده بدون کلید، «شبیه‌ساز CryptoSniper» را اضافه کنید. کلیدهای واقعی با AES-256-GCM رمزنگاری می‌شوند و متغیر `EXCHANGE_CREDENTIAL_KEYS` باید به‌صورت `version:urlsafe-base64` تنظیم شود. `scripts/bootstrap.py` برای محیط توسعه یک کلید خصوصی تصادفی می‌سازد. برای rotation، کلید نسخه جدید را به انتهای keyring اضافه کنید؛ حذف کلید قدیمی قبل از re-encrypt رکوردها ممنوع است.

## بررسی خودکار

```bash
uv run ruff check backend tests scripts
uv run ruff format --check backend tests scripts
uv run python backend/manage.py check
uv run python backend/manage.py makemigrations --check --dry-run
uv run pytest
uv run playwright install --with-deps chromium
uv run python scripts/smoke.py
```

smoke فقط روی دیتابیس محلی توسعه و قابل حذف اجرا شود. Workerهای سه صف، Beat و Web را در processهای مستقل می‌سازد و در پایان می‌بندد. نتیجه probe صف سفارش و گزارش، heartbeat زمان‌بندی، ورود واقعی، نمایش HTMX، منوی Alpine و نبود overflow در عرض‌های ۳۲۰/۳۹۰/۷۶۸ را بررسی می‌کند. پس از بستن مرورگر باید receipt Worker در PostgreSQL موجود باشد. screenshotهای بررسی در `.runtime/screenshots/` ایجاد می‌شوند.

`/health/live/` فقط زنده‌بودن Web را بررسی می‌کند. `/health/ready/` اتصال PostgreSQL و Redis cache/broker/results را بررسی می‌کند و در نبود وابستگی 503 می‌دهد. وضعیت Worker/Beat با heartbeat واقعی و اجرای probe جدا سنجیده می‌شود؛ اتصال broker به‌تنهایی به‌معنی وجود Worker نیست.

## تنظیمات Production و Staging

در process manager هاست `DJANGO_SETTINGS_MODULE=config.settings.production` یا `config.settings.staging` را صریحاً تنظیم کنید. secret تصادفی حداقل ۵۰ کاراکتر، Allowed Hosts دقیق و URLهای واقعی DB/Redis لازم‌اند. Production با host wildcard یا secret خالی اجرا نمی‌شود. SQLite پذیرفته نیست. Cookies در Production Secure و HTTPOnly هستند و CSRF فعال است.

```bash
uv sync --frozen --no-dev
uv run --no-dev python backend/manage.py migrate
uv run --no-dev python backend/manage.py collectstatic --noinput
uv run --no-dev gunicorn --chdir backend config.wsgi:application --bind 127.0.0.1:8000
```

برای ASGI، `uvicorn config.asgi:application --app-dir backend` قابل استفاده است. TLS باید روی هاست یا reverse proxy تنظیم شود. فقط پشت proxy قابل اعتماد که هدر ورودی کاربر را حذف می‌کند `DJANGO_PROXY_SSL_HEADER=true` شود. مشخصات هاست و استقرار واقعی در S19 بررسی خواهند شد؛ این سند گواه استقرار روی سرور کاربر نیست.

## مرز تحویل

نسخه 0.3.0rc1 اتصال امن، شبیه‌ساز و همگام‌سازی صرافی را اضافه می‌کند. Adapter خواندنی Binance پیاده‌سازی شده، اما تا آزمایش با کلید مجاز کاربر «اتصال واقعی تأییدشده» محسوب نمی‌شود. ارسال سفارش واقعی همچنان مسدود است؛ parser سیگنال و موتور معامله هنوز فعال نیستند. Telethon و AI صرفاً در S21 اضافه می‌شوند.

## Dashboard و مدیریت معاملات 0.14

پس از ورود، داشبورد موجودی و نتایج واقعی همان کاربر را به تفکیک حساب و ارز نشان می‌دهد. برای نرخ/موجودی قدیمی یا نامعلوم، ابتدا اتصال و همگام‌سازی حساب را بررسی کنید؛ عدد برآوردی جای موجودی قابل معامله نیست.

در «معاملات و تاریخچه»، فیلتر حساب/نماد/منبع/وضعیت و pagination موجود است. در جزئیات، متن اصلی/طرح/Fills و رویدادها را بررسی کنید. «بستن باقی‌مانده» نیاز به تأیید صریح دارد و تنها پس از نتیجهٔ Worker و Fill، بسته‌شدن قطعی است. انتظار قیمت با شکست سفارش یکی نیست؛ در نتیجهٔ ورود نامعلوم/ناقص ابتدا مرکز عملیات و تطبیق را اجرا کنید. تغییر Stop/trailing و توقف ورود جدید نیز تأیید می‌خواهند. توقف ورود جدید خروج حفاظتی را متوقف نمی‌کند.

ارتقای Ubuntu 24.04 از `scripts/deploy.sh` همان release رسمی و checksum ثابت را می‌گیرد. ابتدا `--check` و سپس نصب را اجرا کنید. نصب‌کننده Stage14 داده، رمز ورود و keyring قبلی را حفظ و headerهای دقیق مدیریت‌شده Stage01–14 را شناسایی می‌کند. فایل Nginx ناشناس را بازنویسی نمی‌کند؛ backup و rollback ادامه دارند. نصب موفق Stage14 با لاگ اپراتور در 2026-10-17 تأیید شده است؛ پذیرش مرورگر عمومی همچنان باز است.

## Reports و PWA نسخه 0.16

Stage15 محاسبات Decimal و گزارش‌های aggregate/CSV/SVG را اضافه می‌کند و Stage16 رابط موبایل/دسکتاپ و PWA را تکمیل می‌کند. Service Worker فقط static assetهای عمومی را cache می‌کند؛ پاسخ خصوصی، API، navigation و عملیات POST هرگز برای اجرای آفلاین ذخیره نمی‌شوند. نصب‌کننده Stage16 نصب مدیریت‌شده Stage14 و headerهای دقیق Stage01–16 را می‌پذیرد، اما snippet ناشناس یا تغییر هم‌زمان Nginx را بدون بازنویسی رد می‌کند.

لاگ اپراتور نصب موفق Stage14 را تأیید کرده است. برای Stage16 ابتدا `scripts/deploy.sh --check` و سپس نصب عادی را اجرا کنید؛ نتیجهٔ نصب 0.16 تا ارائهٔ لاگ جدید تأییدشده محسوب نمی‌شود.
